###################
Ananda Cindy Adista Putri 
FSWD1
###################

###################
Latihan Implementasi Slicing Figma Dalam Framework Codeigniter
###################
