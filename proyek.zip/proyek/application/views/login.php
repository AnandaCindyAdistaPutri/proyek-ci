<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Login Techno Red</title>

    <!-- Bootstrap -->
    <link rel="shorcut icon" href="logo.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://cdn.jsdelivr.net/npm/html5shiv@3.7.3/dist/html5shiv.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/respond.js@1.4.2/dest/respond.min.js"></script>
    <![endif]-->
    <style>
        body {
            background-color: #E1FFEE;
        }

        .pic {
            width: 50%;
            height: 100%;
            background-color: #22CAFF;
            border-radius: 20px 0 0 20px;
        }
    </style>
</head>

<body>

    <div style="width: 700px; height: 350px; margin: 80px auto; background-color: white; border-radius: 10px;">

        <div class="col-sm-6 col-dm-6 pic">
            <div align="center" style="line-height: 350px;"><img src="<?= base_url('image/'); ?>logo.png" alt="" width="200"></div>
        </div>
        <div class="col-sm-6 col-dm-6"><br><br>
            <h2 align="center"><b><u>LOGIN</u></b></h2>
            <form action="<?= base_url('index.php/controller/'); ?>">
                <div class="form-group">
                    <label for="exampleInputEmail1">Email</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email">
                    <a href="#" style="color: black; float: right; font-size: 12px;">Lupa Password?</a>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                </div>
                <button type="submit" class="btn" style="width: 100%; background-color: #22CAFF; color: white;">Masuk</button>
            </form>
            <br>
            <p align="center">Belum punya akun? <a href="http://wa.me/6285764441284">buat akun</a></p>
        </div>
    </div>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
</body>

</html>